require('../../common/options')('semantic')
