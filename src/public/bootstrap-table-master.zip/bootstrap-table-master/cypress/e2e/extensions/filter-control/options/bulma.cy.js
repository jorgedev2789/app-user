require('../../../../extensions/filter-control/options')('bulma')
