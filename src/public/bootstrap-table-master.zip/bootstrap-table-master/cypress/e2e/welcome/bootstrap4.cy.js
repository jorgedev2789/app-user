require('../../common/welcome')('bootstrap4')
